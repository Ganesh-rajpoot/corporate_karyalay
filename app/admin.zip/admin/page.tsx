// app/admin/page.tsx
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { 
  FiUsers, 
  FiTrendingUp, 
  FiClock,
  FiArrowRight,
  FiCheckCircle,
  FiUserPlus,
  FiCalendar,
  FiAlertCircle
} from 'react-icons/fi';

// Types
interface LeadStats {
  total: number;
  new: number;
  contacted: number;
  inProgress: number;
  converted: number;
  lost: number;
}

interface RecentLead {
  id: string;
  name: string;
  email: string;
  phone: string;
  services: string;
  status: string;
  createdAt: string;
  source: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [recentLeads, setRecentLeads] = useState<RecentLead[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // API Base URL - Change this to your Node.js API URL
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Fetch stats
        const statsRes = await fetch(`${API_BASE_URL}/leads/stats`);
        if (!statsRes.ok) {
          throw new Error(`Failed to fetch stats: ${statsRes.status}`);
        }
        const statsData = await statsRes.json();
        setStats(statsData);

        // Fetch recent leads
        const leadsRes = await fetch(`${API_BASE_URL}/leads/recent?limit=8`);
        if (!leadsRes.ok) {
          throw new Error(`Failed to fetch leads: ${leadsRes.status}`);
        }
        const leadsData = await leadsRes.json();
        setRecentLeads(leadsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error instanceof Error ? error.message : 'Failed to load dashboard data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [API_BASE_URL]);

  const statCards = [
    { 
      label: 'Total Leads', 
      value: stats?.total || 0, 
      icon: FiUsers, 
      color: 'text-blue-500',
      bg: 'bg-blue-50',
      change: '+12%'
    },
    { 
      label: 'New Leads', 
      value: stats?.new || 0, 
      icon: FiUserPlus, 
      color: 'text-green-500',
      bg: 'bg-green-50',
      change: '+8%'
    },
    { 
      label: 'In Progress', 
      value: stats?.inProgress || 0, 
      icon: FiClock, 
      color: 'text-orange-500',
      bg: 'bg-orange-50',
      change: '+5%'
    },
    { 
      label: 'Converted', 
      value: stats?.converted || 0, 
      icon: FiCheckCircle, 
      color: 'text-purple-500',
      bg: 'bg-purple-50',
      change: '+15%'
    },
  ];

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      new: 'bg-green-100 text-green-700',
      contacted: 'bg-blue-100 text-blue-700',
      'in-progress': 'bg-orange-100 text-orange-700',
      converted: 'bg-purple-100 text-purple-700',
      lost: 'bg-red-100 text-red-700',
    };
    return styles[status] || 'bg-gray-100 text-gray-700';
  };

  const getStatusDot = (status: string) => {
    const colors: Record<string, string> = {
      new: 'bg-green-500',
      contacted: 'bg-blue-500',
      'in-progress': 'bg-orange-500',
      converted: 'bg-purple-500',
      lost: 'bg-red-500',
    };
    return colors[status] || 'bg-gray-500';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-gray-500 mt-4 text-sm">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <FiAlertCircle className="w-8 h-8 text-red-500" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Error Loading Dashboard</h3>
          <p className="text-sm text-gray-500 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-gold-500 text-primary-900 rounded-lg font-medium hover:bg-gold-600 transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-primary-900">
            Dashboard
          </h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Welcome back! Here's your lead overview.
          </p>
        </div>
        <div className="flex items-center gap-3 text-sm text-gray-500">
          <FiCalendar className="w-4 h-4" />
          <span>{new Date().toLocaleDateString('en-IN', { 
            weekday: 'long', 
            day: '2-digit', 
            month: 'long', 
            year: 'numeric' 
          })}</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => (
          <div key={index} className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100 hover:shadow-md transition">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">{stat.label}</p>
                <p className="text-2xl font-bold text-primary-900 mt-1">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.bg} rounded-xl flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <span className="text-xs text-green-600 font-medium">{stat.change}</span>
              <span className="text-xs text-gray-400">vs last month</span>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Leads */}
      <div className="bg-white rounded-2xl shadow-soft border border-gray-100 overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-primary-900">Recent Leads</h2>
            <p className="text-sm text-gray-500">Latest submissions</p>
          </div>
          <Link 
            href="/admin/leads" 
            className="text-sm text-gold-600 hover:text-gold-700 font-medium flex items-center gap-1"
          >
            View All
            <FiArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lead</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentLeads.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-gray-500">
                    <FiUsers className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                    No leads found
                  </td>
                </tr>
              ) : (
                recentLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-50 transition">
                    <td className="px-5 py-3.5">
                      <div>
                        <p className="font-medium text-primary-900 text-sm">{lead.name}</p>
                        <p className="text-xs text-gray-500">{lead.email}</p>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-600">{lead.services}</td>
                    <td className="px-5 py-3.5">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                        lead.source === 'contact' 
                          ? 'bg-blue-50 text-blue-700' 
                          : 'bg-purple-50 text-purple-700'
                      }`}>
                        {lead.source}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full ${getStatusDot(lead.status)}`} />
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusBadge(lead.status)}`}>
                          {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">
                      {new Date(lead.createdAt).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="px-5 py-3.5">
                      <Link 
                        href={`/admin/leads/${lead.id}`}
                        className="text-sm text-gold-600 hover:text-gold-700 font-medium"
                      >
                        View
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}