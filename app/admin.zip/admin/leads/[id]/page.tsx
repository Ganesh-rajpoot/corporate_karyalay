// app/admin/leads/[id]/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  FiArrowLeft, 
  FiUser, 
  FiMail, 
  FiPhone, 
  FiFileText,
  FiClock,
  FiEdit2,
  FiTrash2,
  FiCheckCircle,
  FiCalendar,
  FiAlertCircle
} from 'react-icons/fi';

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  services: string;
  message: string;
  source: string;
  status: 'new' | 'contacted' | 'in-progress' | 'converted' | 'lost';
  createdAt: string;
  updatedAt: string;
  notes?: string;
}

const statusOptions = [
  { value: 'new', label: 'New', color: 'bg-green-500' },
  { value: 'contacted', label: 'Contacted', color: 'bg-blue-500' },
  { value: 'in-progress', label: 'In Progress', color: 'bg-orange-500' },
  { value: 'converted', label: 'Converted', color: 'bg-purple-500' },
  { value: 'lost', label: 'Lost', color: 'bg-red-500' },
];

export default function LeadDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [lead, setLead] = useState<Lead | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [status, setStatus] = useState<Lead['status']>('new');
  const [notes, setNotes] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // API Base URL
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    const fetchLead = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/leads/${params.id}`);
        if (!response.ok) throw new Error('Lead not found');
        const data = await response.json();
        setLead(data);
        setStatus(data.status);
        setNotes(data.notes || '');
      } catch (error) {
        console.error('Error fetching lead:', error);
        setError('Failed to load lead details');
      } finally {
        setIsLoading(false);
      }
    };

    fetchLead();
  }, [params.id, API_BASE_URL]);

  const handleUpdate = async () => {
    setIsUpdating(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/leads/${params.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status, notes }),
      });

      if (!response.ok) throw new Error('Failed to update lead');

      const updated = await response.json();
      setLead(updated);
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating lead:', error);
      setError('Failed to update lead');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this lead?')) return;

    try {
      const response = await fetch(`${API_BASE_URL}/leads/${params.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        router.push('/admin/leads');
      }
    } catch (error) {
      console.error('Error deleting lead:', error);
      setError('Failed to delete lead');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-gray-500 mt-4 text-sm">Loading lead details...</p>
        </div>
      </div>
    );
  }

  if (error || !lead) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <FiAlertCircle className="w-8 h-8 text-red-500" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Lead Not Found</h3>
          <p className="text-sm text-gray-500 mb-4">{error || 'The lead you are looking for does not exist.'}</p>
          <Link 
            href="/admin/leads" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-gold-500 text-primary-900 rounded-lg font-medium hover:bg-gold-600 transition"
          >
            <FiArrowLeft className="w-4 h-4" />
            Back to Leads
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Link 
            href="/admin/leads" 
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <FiArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-display font-bold text-primary-900">
              {lead.name}
            </h1>
            <p className="text-sm text-gray-500">Lead ID: #{lead.id}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition text-sm"
          >
            <FiEdit2 className="w-4 h-4" />
            Edit
          </button>
          <button
            onClick={handleDelete}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 rounded-xl hover:bg-red-50 transition text-sm"
          >
            <FiTrash2 className="w-4 h-4" />
            Delete
          </button>
        </div>
      </div>

      {/* Lead Details */}
      <div className="grid md:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="md:col-span-2 space-y-6">
          {/* Contact Info */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Contact Information</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-600">
                <FiUser className="w-5 h-5 text-gold-500" />
                <span>{lead.name}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <FiMail className="w-5 h-5 text-gold-500" />
                <a href={`mailto:${lead.email}`} className="hover:text-gold-600 transition">
                  {lead.email}
                </a>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <FiPhone className="w-5 h-5 text-gold-500" />
                <a href={`tel:${lead.phone}`} className="hover:text-gold-600 transition">
                  {lead.phone}
                </a>
              </div>
            </div>
          </div>

          {/* Message */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Message</h2>
            <p className="text-gray-600 leading-relaxed">{lead.message}</p>
          </div>

          {/* Notes */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Notes</h2>
            {isEditing ? (
              <div className="space-y-3">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold-500/50 focus:border-gold-500 outline-none transition resize-y"
                  rows={4}
                  placeholder="Add notes about this lead..."
                />
                <div className="flex gap-3">
                  <button
                    onClick={handleUpdate}
                    disabled={isUpdating}
                    className="px-6 py-2 bg-gold-500 text-primary-900 rounded-xl font-semibold hover:bg-gold-600 transition disabled:opacity-50"
                  >
                    {isUpdating ? 'Saving...' : 'Save Notes'}
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-6 py-2 border border-gray-200 rounded-xl hover:bg-gray-50 transition"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div>
                {lead.notes ? (
                  <p className="text-gray-600 leading-relaxed">{lead.notes}</p>
                ) : (
                  <p className="text-gray-400 italic">No notes added yet</p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Status</h2>
            {isEditing ? (
              <div className="space-y-3">
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as Lead['status'])}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold-500/50 focus:border-gold-500 outline-none transition"
                >
                  {statusOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleUpdate}
                  disabled={isUpdating}
                  className="w-full px-4 py-2 bg-gold-500 text-primary-900 rounded-xl font-semibold hover:bg-gold-600 transition disabled:opacity-50"
                >
                  {isUpdating ? 'Updating...' : 'Update Status'}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className={`w-3 h-3 rounded-full ${statusOptions.find(s => s.value === lead.status)?.color}`} />
                <span className="font-medium">
                  {statusOptions.find(s => s.value === lead.status)?.label}
                </span>
              </div>
            )}
          </div>

          {/* Source */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Source</h2>
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
              lead.source === 'contact' 
                ? 'bg-blue-50 text-blue-700' 
                : 'bg-purple-50 text-purple-700'
            }`}>
              {lead.source}
            </span>
          </div>

          {/* Timeline */}
          <div className="bg-white rounded-2xl p-6 shadow-soft border border-gray-100">
            <h2 className="font-bold text-primary-900 mb-4">Timeline</h2>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <FiCalendar className="w-4 h-4 text-gold-500 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Created</p>
                  <p className="text-sm text-gray-700">
                    {new Date(lead.createdAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <FiClock className="w-4 h-4 text-gold-500 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Last Updated</p>
                  <p className="text-sm text-gray-700">
                    {new Date(lead.updatedAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}